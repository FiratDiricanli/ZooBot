# 1. Bilgi Tabanı (Knowledge Base) Oluşturma
# Anahtar kelimeler ve cevapları içeren bir sözlük (dictionary)
HAYVAN_BILGILERI = {
    "aslan ne yer": "Aslanlar etoburdur ve genellikle büyük memelileri avlarlar.",
    "panda nerede yaşar": "Pandalar Çin'in dağlık bölgelerinde yaşar ve bambu ormanlarını tercih ederler.",
    "zürafa boyu": "Zürafalar dünyanın en uzun hayvanlarıdır, boyları 5.5 metreye kadar ulaşabilir.",
    "fil hakkında": "Filler dünyanın karadaki en büyük hayvanlarıdır ve çok güçlü hafızaları vardır.",
    # ... buraya daha fazla Soru-Cevap ekleyeceksiniz
}

def hayvan_botu_yanitla(kullanici_sorusu):
    # Soruyu küçük harfe çevirip boşlukları temizleyelim (NLP'nin ilk adımıdır)
    soru = kullanici_sorusu.lower().strip()

    # 2. Anahtar Kelime Kontrolü (Rule-Based Logic)
    for anahtar_soru, cevap in HAYVAN_BILGILERI.items():
        if anahtar_soru in soru:
            return cevap
    
    # Eğer hiçbir anahtar kelime eşleşmezse
    return "Üzgünüm, bu hayvan veya soru hakkında henüz bir bilgim yok. Başka bir şey sorar mısın?"

# 3. Botu Çalıştırma (Kullanıcı Arayüzü)
print("Merhaba! Ben Hayvan Bilgi Botu. Bana hayvanlarla ilgili sorular sorabilirsin (Çıkmak için 'çıkış' yaz).")

while True:
    kullanici_girisi = input("Sen: ")
    
    if kullanici_girisi.lower() in ["çıkış", "exit", "dur"]:
        print("Görüşmek üzere!")
        break
        
    yanit = hayvan_botu_yanitla(kullanici_girisi)
    print(f"Bot: {yanit}")